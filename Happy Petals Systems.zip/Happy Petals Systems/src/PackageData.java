/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class PackageData {
    public String name;
    public String price;
    
    //default constructor
    public PackageData(){
        name = "xxx";
        price = "xxx";
    }
    
     //normal constructor
    public PackageData(String name, String price){
        this.name = name;
        this.price = price;
}
    
}
     
